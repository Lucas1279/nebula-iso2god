@echo off
setlocal
cd /d "%~dp0"
py -3 ftp_helper.py
if errorlevel 1 (
  echo.
  echo Python Launcher failed. Trying the python command...
  python ftp_helper.py
)
if errorlevel 1 (
  echo.
  echo Could not start the helper. Install Python 3 and try again.
  pause
)
endlocal
