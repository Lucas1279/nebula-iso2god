Nebula ISO2GOD — Mac timeout-fixed click-to-run package

1. Unzip this folder.
2. Double-click “Start Nebula ISO2GOD.command”. It opens Terminal, starts the local helper, and opens the website in your browser.
3. Keep the Terminal window open while converting/uploading. When done, press Control-C in that window to stop the helper.

If Finder says the command file cannot run because you lack access privileges (for an older download), open Terminal, type `chmod u+x `, drag the `.command` file into Terminal, and press Return; then double-click it. If macOS blocks the first launch for security, Control-click the file and choose Open, then confirm Open. This helper requires Python 3. The helper binds to the Mac only (127.0.0.1). FTP connection/login timeout is 25 seconds; transfer idle timeout is 180 seconds.

This is a click-to-run launcher, not a signed/notarized Mac application. Do not run a second helper at the same time. If FTP disconnects during a file, the page pauses and offers “Retry file & continue.” Restore the Xbox/LAN connection, keep the page and Terminal helper open, and retry. The failed file is resent from its beginning (not resumed at a byte offset); any partial console copy is overwritten and conversion continues. If you cancel or the page reports a final failure, treat the current package as incomplete and do not launch it from Aurora; remove any unconfirmed partial file/package before starting over.
The ISO conversion workflow can import a .7z image archive locally in recent Safari, Chrome, or Edge. For raw XBLA/XBLIG uploads, unzip the game archive on your Mac first, then select the extracted Title ID folder (such as `584111FF`) or parent game folder—not the outer archive, only the `000D0000` folder, or an individual file. The overall job bar tracks all selected content bytes; a separate blue bar tracks the current file. Open the page through the local helper at `http://127.0.0.1:8765/`; do not open `index.html` directly. The helper serves the bundled worker/WASM assets from `vendor/`. Keep the extracted source files available until the FTP upload and any retry are complete. Keep the `vendor` folder beside `index.html`. See README_FTP.md for details.

SNES360 ROMs: choose the SNES360 ROM uploader in the page. It copies `.sfc`, `.smc`, `.swc`, and `.fig` files unchanged; one `.7z` archive at a time is unpacked locally to those ROM files only. The default SNES360 v0.32 HDD destination is `Hdd1:/Emus/Snes360/Roms/`; USB0 uses `Usb0:/Roms/`, while older v0.21 USB installs may use `Usb0:/_Emus/Snes360/Roms/`. Use the page presets/custom fields for your installation.

SNES360 folder drops: recursively scans the dropped folder, accepts supported ROM files only, flattens them into the selected Xbox ROM folder, and skips unrelated files. The numbered ROM list is the exact sequential FTP upload order; complete ROM files are copied unchanged. Duplicate destination filenames are skipped.

FTP manager: **New folder** creates the directory at the current location and immediately opens it, including when empty, so you can upload files or drop a folder into it.

FTP file manager: any file type uploads unchanged. Directly choosing or dropping one `.zip` or `.7z` unpacks it locally and uploads its safe file entries without extension filtering; the source archive on your Mac is left intact. Archives inside a folder upload stay as files.
