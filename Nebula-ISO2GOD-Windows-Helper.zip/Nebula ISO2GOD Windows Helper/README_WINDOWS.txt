Nebula ISO2GOD — Windows helper

Requirements
- Windows 10 or 11
- Python 3 installed (python.org installer; enable the Python launcher if offered)
- Chrome or Edge recommended

Start the local helper
1. Extract the complete "Nebula ISO2GOD Windows Helper" folder from this ZIP.
2. Double-click "Start Nebula ISO2GOD.bat". If Windows SmartScreen appears, verify the file came from the Nebula ISO2GOD website and choose the option to run it.
3. Leave the Command Prompt window open while using FTP. The helper opens the local app automatically; if needed, open Chrome and visit http://127.0.0.1:8765/.
4. To stop the helper, focus its Command Prompt window and press Ctrl+C, then confirm if Windows asks.

Chrome/Edge can use the browser's native folder picker for GOD folder output. The local helper is required for Xbox and PS4 FTP; it runs only on this computer and binds to 127.0.0.1. For PS4, enable the console FTP server, connect on the trusted home LAN, and use the PS4 FTP package-manager mode (GoldHEN commonly uses port 2121). The manager opens or creates `/data/pkg`; FTP copies PKGs only and does not install them. Temporary upload staging is cleaned locally; uploaded files on the console are not auto-deleted. Use FTP only on a trusted home LAN. The Python helper and all web assets are included in this ZIP; no Mac .command launcher is used.

If the .bat says Python was not found, install Python 3, close the old command window, and run the .bat again. Do not open index.html as a file:// page; use the local page opened by the helper.
