#!/bin/bash
cd "$(dirname "$0")"
echo "Starting Nebula ISO2GOD FTP helper. Keep this Terminal window open during uploads."
echo "When finished, press Control-C here to stop the helper."
python3 ftp_helper.py
