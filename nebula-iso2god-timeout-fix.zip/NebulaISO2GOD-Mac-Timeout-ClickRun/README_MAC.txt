Nebula ISO2GOD — Mac timeout-fixed click-to-run package

1. Unzip this folder.
2. Double-click “Start Nebula ISO2GOD.command”. It opens Terminal, starts the local helper, and opens the website in your browser.
3. Keep the Terminal window open while converting/uploading. When done, press Control-C in that window to stop the helper.

If macOS blocks the first launch, Control-click the .command file and choose Open, then confirm Open. This helper requires Python 3. The helper binds to the Mac only (127.0.0.1). FTP connection/login timeout is 25 seconds; transfer idle timeout is 180 seconds.

This is a click-to-run launcher, not a signed/notarized Mac application. Do not run a second helper at the same time. If FTP disconnects during a file, the page pauses and offers “Retry file & continue.” Restore the Xbox/LAN connection, keep the page and Terminal helper open, and retry. The failed file is resent from its beginning (not resumed at a byte offset); any partial console copy is overwritten and conversion continues. If you cancel or the page reports a final failure, treat the current package as incomplete and do not launch it from Aurora; remove any unconfirmed partial file/package before starting over.
The ISO workflow can also import a .7z archive locally in recent Chrome or Edge. Only supported disc images are extracted; other archive entries are skipped, and nothing is uploaded by the archive importer. Keep the `vendor` folder beside `index.html`. See README_FTP.md for details.
